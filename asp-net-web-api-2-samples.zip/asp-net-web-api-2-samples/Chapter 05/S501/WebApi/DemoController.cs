﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace WebApi
{
    public class DemoController : ApiController
    {
        public void GetXxx() { }
        public void PostXxx() { }
        public void PutXxx() { }
        public void DeleteXxx() { }
        public void HeadXxx() { }
        public void OptionsXxx() { }
        public void PatchXxx() { }
        public void Other() { }
    }

}