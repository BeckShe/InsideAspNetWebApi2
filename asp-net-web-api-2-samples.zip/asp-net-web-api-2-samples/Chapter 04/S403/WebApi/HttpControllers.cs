﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace HttpControllers1
{
    public class FooBarController : ApiController
    { }
    public class FoobarController : ApiController
    { }
}

namespace HttpControllers2
{
    public class FooBarController : ApiController
    { }
    public class FoobarController : ApiController
    { }
}
