﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace HttpControllers1
{
    public class FooController : ApiController
    { }

    public class BarController : ApiController
    { }
}

namespace HttpControllers2
{
    public class BarController : ApiController
    { }

    public class BazController : ApiController
    { }
}



