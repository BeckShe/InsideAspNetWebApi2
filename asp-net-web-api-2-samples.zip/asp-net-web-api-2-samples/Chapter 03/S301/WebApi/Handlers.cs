﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;

namespace WebApi
{
    public class FooHandler : DelegatingHandler{}

    public class BarHandler : DelegatingHandler{}

    public class BazHandler : DelegatingHandler{}
}